# Alephant MCP Server

Model Context Protocol server for **Alephant BYO-KEY**: FinOps metrics, virtual keys, and workspace analytics from Cursor, Claude Desktop, or any MCP host.

## Modes

| Mode | Environment | Tools |
|------|-------------|--------|
| **VK** | `ALEPHANT_VIRTUAL_KEY` | Cockpit-scoped usage + 3 VK tools (7 tools total incl. shared) |
| **Manager** | `ALEPHANT_PAT` + `ALEPHANT_WORKSPACE_ID` | Workspace-wide management (15 tools total incl. shared) |

PAT takes precedence when `ALEPHANT_PAT` is non-empty. If neither VK nor PAT is set, the process exits with an error (no mock data).

**Required (both modes):** `ALEPHANT_API_BASE_URL`  
**Optional:** `ALEPHANT_RATE_LIMIT_RPM` (default `60`, use `0` to disable client-side throttling)

### Windows / `npx` troubleshooting

If `npx -y @alephantai/mcp` prints `'alephant-mcp' is not recognized`, use either:

```powershell
npx --yes --package=@alephantai/mcp alephant-mcp
```

or run Node on the installed entry (after `npm install @alephantai/mcp` in a folder):

```powershell
node .\node_modules\@alephantai\mcp\bin\alephant-mcp.js
```

Package **0.0.2+** ships a root `bin/alephant-mcp.js` shim so Windows npm shims resolve reliably; republish if you still see the error on **0.0.1**.

## Cursor / Claude config

**Virtual Key (read-only / scoped cockpit):**

```json
{
  "mcpServers": {
    "alephant": {
      "command": "npx",
      "args": ["-y", "@alephantai/mcp"],
      "env": {
        "ALEPHANT_API_BASE_URL": "https://api.alephant.ai",
        "ALEPHANT_VIRTUAL_KEY": "vk-..."
      }
    }
  }
}
```

**Personal Access Token (manager):**

```json
{
  "mcpServers": {
    "alephant-workspace-a": {
      "command": "npx",
      "args": ["-y", "@alephantai/mcp"],
      "env": {
        "ALEPHANT_API_BASE_URL": "https://api.alephant.ai",
        "ALEPHANT_PAT": "pat_...",
        "ALEPHANT_WORKSPACE_ID": "00000000-0000-0000-0000-000000000000"
      }
    }
  }
}
```

Use **separate `mcpServers` entries** per workspace when you have multiple PATs.

## CLI audit

```bash
npx --yes --package=@alephantai/mcp alephant-mcp --audit
```

- **VK:** prints cockpit `scope` + `usage-summary` (billing cycle).  
- **Manager:** prints workspace id + `GET /api/v1/analytics/overview`.

## Tools (summary)

Shared (both modes): `get_usage_summary`, `get_daily_costs`, `get_cost_by_model`, `list_available_models`  
VK only: `get_my_scope`, `get_my_budget`, `get_my_recent_requests`  
Manager only: `get_workspace_overview`, `list_virtual_keys`, `create_virtual_key`, `update_key_budget`, `revoke_virtual_key`, `list_agents`, `get_agent_analytics`, `list_departments`, `get_department_analytics`, `get_subscription_info`, `set_budget_policy`

`get_request_logs` is **not** included (JWT-only backend route).

## Prompts & resources

- **cost_audit_report** — both modes  
- **cost_optimization** — manager only  
- **model-catalog** — static JSON resource (`data/model-catalog.json`)

## Development

```bash
npm install
npm test
npm run build
```

## Package

Published as **`@alephantai/mcp`** (`alephant-mcp` binary).
